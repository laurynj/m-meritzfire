$(function() {
	renewalUI.init();   // 초기설정

	seniorUI.init(); //시니어 초기설정
});

//  ui/ux 관련  script 
var prevFocus;      // 이전 focus element
var renewalUI = {
	// 초기 설정
	init: function(_id) {
		this.inpSetting();          // input focus
		this.floatingShadow();      // 하단 floating 영역 shadow
		this.popBottomShadow(_id);  // 팝업(full, floating) 하단 버튼 영역 shadow
		this.setTabRadio();         // tab 형태 radio button
		this.setAccordion();        // accordion setup
		this.setTabContent();       // tab content
		this.setTodayPicker();      // 오늘 날짜 default
		this.gnbMenu();             // gnb menu open/close
		// this.cardListAni();      // card list animation
		this.dArsAutoFocus();       // 디지털ARS 키패드 동작시 dArsBtns 숨김, 포커스 이동
		this.setAccordionLast();    // accordion last 최소높이 설정
		this.listSelectFnc();
		// this.prevFocusSave();       //
		this.switchOnOff(); 		//switch on and off 20250612
	},

	// input box setting 
	inpSetting: function() {
		var iptObj = $('.form_item .inp_box').find('input.inp_txt, select, button, a');

		if (iptObj.length < 1) return false;

		$.each(iptObj, function(i, ipt) {
			var ipt = $(ipt);

			ipt.on('focus.inputfocus', function() {
				var selfBox = $(this).closest('.inp_box');
					// iptParent = $(this).closest('.form_item'),
					// iptTop = iptParent.offset().top - 80,
					// doc = (iptParent.closest('.popup').length > 0) ?
					// iptParent.closest('.popup') : $('html');

				$('.inp_box').removeClass('focus');
				selfBox.addClass('focus');

				// input 위치로 scroll
				// if (!!!$(this).hasClass('sel_btn')) {
				// doc.animate({ scrollTop: iptTop +'px' }, 400);
				// };

				// 이외의 영역 클릭 시 focus 제거
				$(document).off('click.iptetc').on('click.iptetc', function(e) {
					var target = e.target;

					if (selfBox.has(target).length < 1) {
						ipt.closest('.inp_box').removeClass('focus');
					}
				});
			});

			//2024-05-22 date_time과 같이 form_item안의 input,select,a,button이 여러개 있는 case 추가 start
			if(ipt.parents('.form_item').hasClass('date_time') || ipt.parents('.form_item').hasClass('col2')) {
				var iptParent = $(this).parents('.form_item').find('.inp_box');
				iptParent.each(function(){
					var iptItem = $(this).find('input.inp_txt, select, button');

					// input:readonly
					!!iptItem.attr('readonly') && $(this).addClass('readonly');

					// input:disabled
					!!iptItem.attr('disabled') && $(this).addClass('disabled');
				})
			}else {
				// input:readonly
				!!ipt.attr('readonly') && ipt.closest('.form_item').addClass('readonly');

				// input:disabled
				!!ipt.attr('disabled') && ipt.closest('.form_item').addClass('disabled');
			}
			//2024-05-22 date_time과 같이 form_item안의 input,select,a,button이 여러개 있는 case 추가 end
		});

		// [type=number]의 maxlength
		$(document).off('input.maxlength').on('input.maxlength', 'input[type=number]', function() {
			var inpLen = $(this).val().length,
				limitLen = Number($(this).attr('maxLength')),
				maxVal = $(this).val().slice(0, limitLen);

			if (limitLen > 0) {
				(inpLen > limitLen) && $(this).val(maxVal);
			}
		});

		// 영문만 입력
		$(document).off('input.enonly').on('input.enonly', 'input.en_only', function() {
			var inpTxt = $(this).val(),
				engVal = inpTxt.replace(/[^A-Za-z, ]/ig, '');

			$(this).val(engVal.toUpperCase());
		});
	},

	// input box focus 이동
	// @param: _next('string', focus 이동시킬 object의 id값)
	moveNextFocus: function(_next) {
		var nowFormbox = !!!_next && $('.form_item').find('.focus'),
			nextObj = !!_next ? $('#'+ _next) : nowFormbox.closest('.form_item').nextAll('.form_item').eq(0).find('input.inp_txt, button, select, a'),
			nextFormbox = nextObj.closest('.inp_box');

		if (nextFormbox.length < 1) return false;

		var timer = setTimeout(function() {
			!!!_next && nowFormbox.removeClass('focus');

			// if (!!nextObj.hasClass('sel_btn')) {
			// nextFormbox.find('.sel_btn').trigger('click');
			// } else {
			// nextObj.focus();
			// }
			nextObj.focus();

			nextFormbox.addClass('focus');

			clearTimeout(timer);
		}, 150);
	},

	// 하단 floating 영역 shadow
	floatingShadow: function() {
		var floatingObj = $('.floating_btm').find('[class^="floating_inner"]'),
			screenH = window.innerHeight,
			docuH = $(document).height();

		if (floatingObj.length < 1) return false;

		// 하단 shadow 추가/삭제
		btmShadow(docuH);

		// 화면 요소의 변동(추가/삭제)으로 인한 shadow 적용 여부
		var doc = document.querySelector('#Wrap');
		var observer = new ResizeObserver((entries) => {
			entries.forEach((entry) => {
				docuH = $(document).height();
				btmShadow(docuH);
				// btmShadow(entry.contentRect.height);
			});
		});
		observer.observe(doc);

		// 하단 shadow 추가/삭제 함수
		function btmShadow(_height) {
			if (_height > screenH) {  // 화면 크기보다 내용이 길 때
				floatingObj.addClass('shadow');
			} else {
				floatingObj.removeClass('shadow');
			}
		}

		// scroll stop 감지 함수
		// 2023-08-31 scrollStop 함수 삭제
		// function scrollStop(callback) {
		//     var that = this,
		//         $this = $(that);

		//     $this.off('scroll.floatbtm').on('scroll.floatbtm', function(e) {
		//         floatingObj.addClass('scr');

		//         clearTimeout($this.data('scrollTimeout'));
		//         $this.data('scrollTimeout', setTimeout(callback.bind(that), 150, e));
		//     });
		// }

		// scrollStop(function(e) {
		//     floatingObj.removeClass('scr');
		// });
	},

	// 팝업(full, floating) 하단 버튼 영역 shadow
	popBottomShadow: function(_id) {
		var popObj = !!!_id ? $('.popup') : $('#'+ _id).find('.popup'),
			popProp = (!!popObj.hasClass('full') || !!popObj.hasClass('floating')) ? true : false;
			popBtm = popObj.find('.pop_bottom'),
			parentH = popObj.outerHeight(),
			popHeaderH = !!popObj.hasClass('floating') ? popObj.find('.pop_header').outerHeight() : '',
			popBodyH = popObj.find('.pop_body').outerHeight(),
			popFooterH = popObj.find('.pop_bottom').outerHeight();

		if (!!!popObj.hasClass('open')) return false;
		if (!!!popProp) return false;

		// 하단 shadow 추가/삭제
		btmShadow(popHeaderH + popBodyH + popFooterH);

		// 화면 요소의 변동(추가/삭제)으로 인한 shadow 적용 여부
		var popup = !!!_id ? document.querySelector('.popup .pop_body') : document.querySelector('#'+ _id +' .pop_body');
		var observer = new ResizeObserver((entries) => {
			entries.forEach((entry) => {
				btmShadow(entry.borderBoxSize[0].blockSize + popFooterH + popHeaderH);
			});
		});
		observer.observe(popup);

		// 하단 shadow 추가/삭제 함수
		function btmShadow(_height) {
			if (_height > parentH) {
				popBtm.find('.inner').addClass('shadow');
			} else {
				popBtm.find('.inner').removeClass('shadow');
			}
		}

		// bottom-up popup일 때 제외
		if (!!popObj.hasClass('floating')) return false;

		// scroll stop 감지 함수
		// 2023-08-31 scrollStop 함수 삭제
		// function scrollStop(callback) {
		//     popObj.off('scroll.floatbtm').on('scroll.floatbtm', function(e) {
		//         popBtm.find('.inner').addClass('scr');

		//         clearTimeout(popObj.data('scrollTimeout'));
		//         popObj.data('scrollTimeout', setTimeout(callback.bind(popObj), 150, e));
		//     });
		// }

		// scrollStop(function(e) {
		//     popBtm.find('.inner').removeClass('scr');
		// });
	},

	// tab 형태 radio button
	setTabRadio: function() {
		var rdoGrp = $('.radio_group');

		if (!!!rdoGrp) return false;

		$.each(rdoGrp, function(i, group) {
			var radioGroup = $(group);

			if (!!radioGroup.hasClass('tab_style')) {
				var selBlock = $('<span class="selected"></span>'),
					rdo = radioGroup.find('input[type="radio"]');

				// 이미 적용되어 있을 때 막기
				if (radioGroup.find('.selected').length > 0) return false;

				// 선택 표시 block 추가
				selBlock.appendTo(radioGroup);

				chkMove();

				// radio 선택
				rdo.off('change.tabradio').on('change.tabradio', function() {
					chkMove();
				});

				// 화면 크기 변경 시(가로 ↔ 세로)
				$(window).on('resize', function() {
					chkMove();
				});

				// checked 위치/이동
				function chkMove() {
					var chkedItem = radioGroup.find('input[type="radio"]:checked').closest('.radio_item'),
						chkedWidth = chkedItem.outerWidth(),
						chkedLeft = chkedItem.position().left;

					selBlock.css({ left: chkedLeft +'px', width: chkedWidth +'px' });
				}
			}
		});
	},

	// accordion setup accBtn > accHeader 클릭 변경 2023-12-29
	// 2025-03-02 아코디언과 디자인은 동일한데 기능이 없는 타입(box_details)
	setAccordion: function() {
		var accordion = $('.accordion:not(.box_details)'),
			accBtn = accordion.find('.acc_btn');

		if (accordion.length < 1) return false;

		// 웹접근성 대응
		$.each(accordion, function(i, acc) {
			var accNo = i+1;
				accBtn = $(acc).find('.acc_btn');
				accHeader = $(acc).find('.acc_header');

			$.each(accBtn, function(idx, btn) {
				var itemNo = idx+1,
					panel = $(btn).closest('.acc_item').find('.acc_panel');

				$(btn).attr({ id: 'acc'+ accNo +'_'+ itemNo, 'aria-expended': false, 'aria-controls': 'accpan'+ accNo +'_'+ itemNo });
				panel.attr({ id: 'accpan'+ accNo +'_'+ itemNo, 'role': 'region', 'aria-labelledby': 'acc'+ accNo +'_'+ itemNo });

				// default: open 일 때
				if (!!$(btn).hasClass('open')) {
					$(btn).attr({ 'aria-expended': true });
					$(btn).closest('.acc_item').find('.acc_panel').addClass('active').css({ display: 'block' });
				}
			});

			// 태그이벤트 추가
			const btnTag = document.querySelectorAll(".accordion button.tag");
			if (btnTag.length >= 1) {
				for (const item of btnTag) {
					item.addEventListener("click", (e) => {
						e.stopPropagation();
					})
				}
			}

			// card_wrap 일때 분리
			let trigger;
			let cardWrap;
			if (acc.classList.contains("card_wrap") === true) {
				trigger = accBtn;
				cardWrap = true;
			} else {
				trigger = accHeader;
				cardWrap = false;
			}

			trigger.off('click.accordion').on('click.accordion', function() {
				var panel = $(this).closest('.acc_item').find('.acc_panel');

				if (!!$(acc).hasClass('auto_close')) {
					var panels = $(this).closest('.acc_item').siblings('.acc_item').find('.acc_panel'),
						accBtns = $(this).closest('.acc_item').siblings('.acc_item').find('.acc_btn');

					accBtns.removeClass('open').attr({ 'aria-expended': false });
					accBtns.find('span').html('열기');
					panels.removeClass('active').slideUp(300);
				}

				// card_wrap 일때 분리
				const cntBtn = cardWrap === true ? $(this) : $(this).find('.acc_btn');
				if (!cntBtn.hasClass('open')) {
					cntBtn.addClass('open').attr({ 'aria-expended': true });
					cntBtn.find('span').html('닫기');
					panel.stop().addClass('active').slideDown(300);
				} else {
					cntBtn.removeClass('open').attr({ 'aria-expended': false });
					cntBtn.find('span').html('열기');
					panel.stop().removeClass('active').slideUp(300);
				}
			});
		});
	},

	// accordion setup 수정전
	// setAccordion: function() {
	//     var accordion = $('.accordion'),
	//         accBtn = accordion.find('.acc_btn');

	//     if (accordion.length < 1) return false;

	//     // 웹접근성 대응
	//     $.each(accordion, function(i, acc) {
	//         var accNo = i+1;
	//             accBtn = $(acc).find('.acc_btn');

	//         $.each(accBtn, function(idx, btn) {
	//             var itemNo = idx+1,
	//                 panel = $(btn).closest('.acc_item').find('.acc_panel');

	//             $(btn).attr({ id: 'acc'+ accNo +'_'+ itemNo, 'aria-expended': false, 'aria-controls': 'accpan'+ accNo +'_'+ itemNo });
	//             panel.attr({ id: 'accpan'+ accNo +'_'+ itemNo, 'role': 'region', 'aria-labelledby': 'acc'+ accNo +'_'+ itemNo });

	//             // default: open 일 때
	//             if (!!$(btn).hasClass('open')) {
	//                 $(btn).attr({ 'aria-expended': true });
	//                 $(btn).closest('.acc_item').find('.acc_panel').addClass('active').css({ display: 'block' });
	//             }
	//         });

	//         accBtn.off('click.accordion').on('click.accordion', function() {
	//             var panel = $(this).closest('.acc_item').find('.acc_panel'),
	//                 itemTop = $(this).closest('.acc_item').offset().top,
	//                 parent = (accordion.closest('.popup').length > 0)
	//                         ? $('.popup')
	//                         : $('html'),
	//                 headerH = (accordion.closest('.popup').length > 0)
	//                         ? $('.pop_header').outerHeight()
	//                         : $('#Header').outerHeight();

	//             if (!!$(acc).hasClass('auto_close')) {
	//                 var panels = $(this).closest('.acc_item').siblings('.acc_item').find('.acc_panel'),
	//                     accBtns = $(this).closest('.acc_item').siblings('.acc_item').find('.acc_btn');

	//                 accBtns.removeClass('open').attr({ 'aria-expended': false });
	//                 accBtns.find('span').html('열기');
	//                 panels.removeClass('active').slideUp(300);
	//             }

	//             if (!!!$(this).hasClass('open')) {
	//                 $(this).addClass('open').attr({ 'aria-expended': true });
	//                 $(this).find('span').html('닫기');
	//                 panel.addClass('active').slideDown(300);
	//             } else {
	//                 $(this).removeClass('open').attr({ 'aria-expended': false });
	//                 $(this).find('span').html('열기');
	//                 panel.removeClass('active').slideUp(300);
	//             }

	//             // scroll 이동
	//             // parent.animate({scrollTop: (itemTop - headerH - 16) +'px'}, 400);
	//         });
	//     });
	// },

	// combo-box(select box) setup - layer type
	setCombobox: function(opt) {
		var id = opt.id,
			callback = opt.callback,
			selObj = $('#'+ id),
			selBox = $('#'+ id).closest('.ui_select'),
			initVal = selObj.find('option:not([hidden]):selected').val(),
			initTxt = selObj.find('option:not([hidden]):selected').text(),
			placeholder = selObj.find('option[hidden]').text(),
			optList = selObj.find('option:not([hidden])'),
			comboObjs = '',
			isDisbled = selObj.attr('disabled') ? true : false;

		// custom select box 만들기
		comboObjs += '<button type="button" id="selBtn_'+ id +'" class="sel_btn combo" title="'+ selObj.attr('title') +'"><span class="placeholder">'+ placeholder +'</span></button>';
		comboObjs += '<div class="opt_layer">';
		comboObjs += '<ul>';

		$.each(optList, function(i, opt) {
			var optTxt = opt.text,
				optVal = opt.value,
				selProp = (optVal == initVal) ? 'sel' : '';

				comboObjs += '<li><button type="button" class="opt_btn '+ selProp +'" value="'+ optVal +'"><span>'+ optTxt +'</span></button></li>';
		});

		comboObjs += '</ul>';
		comboObjs += '</div>';

		// custom select box 추가
		selBox.append($(comboObjs));

		renewalUI.inpSetting();

		// option layer 위치 설정
		var screenH = $(window).height(),
			btmAreaH = selBox.closest('.popup').length > 0 ? $('.pop_bottom').outerHeight() : selBox.closest('.contents').siblings('.floating_btm').length > 0 ? $('.floating_btm').outerHeight() : '',
			optLyrTop = selBox.closest('div').offset().top + selBox.closest('div').outerHeight(),
			lyrH = selBox.find('.opt_layer').outerHeight();

		// option layer가 화면 밖을 벗어날 때
		((screenH - btmAreaH) < (optLyrTop + lyrH)) && selBox.find('.opt_layer').addClass('top');

		var selBtn = $('#selBtn_'+ id);     // select box button
		!!initVal && selBtn.find('span').removeClass('placeholder').html(initTxt);
		!!isDisbled && selBtn.attr({'disabled' : 'disabled'});

		// select box click
		selBtn.off('click.selectbtn').on('click.selectbtn', function() {
			var optLayer = $(this).closest('.ui_select').find('.opt_layer'),
				lyrTop = ($(this).closest('div').offset().top + $(this).closest('div').outerHeight()) - $(document).scrollTop(),
				lyrH = optLayer.outerHeight();

			// 열려있는 option layer 닫기
			$('.opt_layer').removeClass('active');

			// option layer 위치 설정
			((screenH - btmAreaH) < (lyrTop + lyrH)) ? optLayer.addClass('top') : optLayer.removeClass('top');

			if (!!!$(this).hasClass('open')) {
				$('.sel_btn.combo').removeClass('open');
				$(this).addClass('open');       // select box 화살표 회전
				optLayer.addClass('active');    // option layer 열기
			} else {
				$('.sel_btn.combo').removeClass('open');
				$(this).removeClass('open');       // select box 화살표 회전
				optLayer.removeClass('active');    // option layer 열기
			}
		});

		// option click
		selBox.find('.opt_btn').off('click.optbtn').on('click.optbtn', function() {
			var btn = $(this).closest('.ui_select').find('.combo'),
				select = $(this).closest('.ui_select').find('select'),
				optlyr = $(this).closest('.opt_layer'),
				selVal = $(this).val(),
				selTxt = $(this).text();

			optlyr.find('.opt_btn').removeClass('sel');
			$(this).addClass('sel');

			btn.find('span').removeClass('placeholder').html(selTxt);
			select.val(selVal);
			select.find('option').attr('selected', false);
			select.find('option[value="'+ selVal +'"]').attr('selected', true);

			btn.removeClass('open');
			optlyr.removeClass('active');

			// callback 실행
			!!callback && callback(selVal);

			// 다음 focus 이동
			renewalUI.moveNextFocus();
		});

		// select box 외부영역 클릭 시 option layer 닫기
		$(document).off('click.selectbox').on('click.selectbox', function(e) {
			if (!!$('.opt_layer').hasClass('active')) {
				var target = $(e.target);

				if (!!!target.hasClass('combo') && $('.opt_layer').has(e.target).length == 0) {
					$('.ui_select').find('.combo').removeClass('open');
					$('.opt_layer').removeClass('active');
				}
			}
		});
	},

	// combo-box(select box) selected - layer type
	selectedCombo: function(opt) {
		var id = opt.id,
			selected = opt.selected,
			selBox = $('#'+ id),
			selOpt = selBox.find('option[value="'+ selected +'"]'),
			selBtn = selBox.closest('.ui_select').find('.sel_btn'),
			optList = selBox.closest('.ui_select').find('.opt_layer'),
			optBtn = optList.find('.opt_btn'),
			selOptBtn = optList.find('.opt_btn[value="'+ selected +'"]');

		// <select>..</select> 설정
		selBox.find('option').attr('selected', false);
		selBox.find('option').eq(selOpt.index()).attr('selected', true);

		// combo-box button 설정
		selBtn.find('span').html(selOpt.text());

		// option button list 설정
		optBtn.removeClass('sel');
		selOptBtn.addClass('sel');
	},

	// combo-box(select box) - bottom-up type
	setPopCombobox: function(opt) {
		var id = opt.id,
			title = opt.title,
			subMsg = opt.subMessage,    // 설명 메시지
			optList = opt.optlist,
			callback = opt.callback,
			callback2 = opt.callback2,
			etcCallback = opt.etcCallback,
			cancelCallback = opt.cancelCallback,
			nextFocus = opt.nextfocus,
			selBtn = $('#'+ id),
			initVal = selBtn.closest('div').find('input[type="hidden"]').val(),
			popContainer = $('#layer_popup_container'),
			popId = 'popSelect_'+ id,
			popup = '';

		// 팝업 만들기
		popup += '<div id="'+ popId +'">';
		popup += '<div class="dimmed_area on">';
		popup += '<div class="popup floating">';
		popup += '<div class="pop_header">';
		popup += '<h1>'+ title +'</h1>';
		popup += '<button type="button" class="pop_close"><span class="hidden">닫기</span></button>';
		popup += '</div>';
		popup += '<div class="pop_body">';
		popup += !!subMsg ? subMsg : '';
		popup += '<ul class="list_select">';

		$.each(optList, function(i) {
			var label = optList[i].label,
				val = optList[i].value,
				info = optList[i].info,
				disabled = optList[i].disabled,
				activeProp = optList[i].value == initVal ? 'active' : '';

			popup += '<li>';
			if(activeProp === 'active') {
				if (!!disabled) {
					popup += '<button type="button" class="opt_btn '+ activeProp +'" title="선택됨" value="'+ val +'" disabled="disabled">';
				}else {
					popup += '<button type="button" class="opt_btn '+ activeProp +'" title="선택됨" value="'+ val +'">';
				}
			}else{
				if (!!disabled) {
					popup += '<button type="button" class="opt_btn '+ activeProp + '" value="'+ val +'" disabled="disabled">';
				}else {
					popup += '<button type="button" class="opt_btn '+ activeProp + '" value="'+ val +'">';
				}
			}

			popup += '<span>'+ label +'</span>';

			if (!!info) {
				popup += '<span class="info">'+ info +'</span>';
			}

			popup += '</button>'
			popup += '</li>';
		});

		popup += '</ul>';
		popup += '</div>';
		popup += '</div>';
		popup += '<div class="dimmed"></div>';
		popup += '</div>';
		popup += '</div>';

		// 팝업 추가
		popContainer.append($(popup));

		// 버튼 화살표 회전
		selBtn.addClass('open');

		var popObj = $('#'+ popId);     // 팝업

		// popup 열기
		this.openPopup(popId);

		var optBtn = popObj.find('.opt_btn');

		// option list 선택
		optBtn.off('click.selectopt').on('click.selectopt', function() {
			var optIdx = $(this).closest('li').index(),
				dispObj = selBtn.find('span'),
				hiddenInp = selBtn.closest('div').find('input[type="hidden"]');

			optBtn.removeAttr('title').removeClass('active');
			$(this).attr({'title' : '선택됨'}).addClass('active');

			// 24.03.27 디지털ars메인에서 setPopCombobox 사용시 메뉴명 변경 방지
			if(!selBtn.hasClass('menu_btn')) {
				dispObj.removeClass('placeholder').html(optList[optIdx].label);
			}

			hiddenInp.val(optList[optIdx].value);


			// 닫은 후 focus 요소
			var returnEl = popObj.find('.popup').data('returnEl');

			if (!!returnEl.length > 0) {
				$('.inp_box').removeClass('focus');
				if (!!returnEl.attr('id')) {
					renewalUI.moveNextFocus(returnEl.attr('id'));
				} else {
					if(returnEl[0].tagName == 'H1') {
						returnEl.attr('tabindex', '0');
					}else{
						returnEl.closest('.inp_box').addClass('focus');
					}

					returnEl.focus();
				}
			}else{
				$('#Header h1').attr('tabindex', '0').focus();
			}

			// 함수 실행
			!!opt.callback && callback(optList[optIdx].value);
			// 함수 실행(value, label 필요한 경우)
			!!opt.callback2 && callback2(optList[optIdx]);
			// combo-popup 닫기
			selectPopClose();

			// 버튼 화살표 회전
			selBtn.removeClass('open');
		});

		// 팝업 이외의 영억 클릭 시 etcCallback option이 있는 경우 etcCallback 함수 호출
		if (!!etcCallback) {
			$('#'+ popId).find('.dimmed').off('click.combodim').on('click.combodim', function() {
				etcCallback();
			});
		}else{
			// 팝업 이외의 영역 클릭 시
			$('#'+ popId).find('.dimmed').off('click.combodim').on('click.combodim', function() {
				// 버튼 화살표 회전
				selBtn.removeClass('open');
			});

		}

		if(!!cancelCallback){
			popObj.find('.pop_close').on('click', function() {
				// 버튼 화살표 회전
				selBtn.removeClass('open');
				cancelCallback();
			});
		}else{
			// 팝업 닫기 버튼 클릭 시
			popObj.find('.pop_close').on('click', function() {
				// 버튼 화살표 회전
				selBtn.removeClass('open');
			});
		}

		// combo-popup 닫기
		function selectPopClose() {
			// 버튼 화살표 회전
			selBtn.removeClass('open');

			// popup 닫기
			popObj.find('.popup').removeClass('open');
			renewalUI.allowScroll();

			var timer = setTimeout(function() {
				//팝업 외 다른영역 포커스 진입 방지 해제
				popObj.attr({'aria-hidden' : true});
				if(popContainer.find('.popup.open').length == 0) {
					$('.renew .skipnav, #Wrap').removeAttr('aria-hidden');
				}else{
					popContainer.find('.popup.open').closest('[aria-hidden]').attr({'aria-hidden' : false});
				}

				popObj.find('.dimmed_area').removeClass('on');
				popObj.remove();

				clearTimeout(timer);
			}, 300);

			// 다음 focus 이동
			if (nextFocus == true || nextFocus == 'undefined') {
				renewalUI.moveNextFocus();
			}
		}
	},

	// combo-box(select box) - bottom-up type
	setPopChkCombobox: function(opt) {
		var id = opt.id,
			title = opt.title,
			subMsg = opt.subMessage,    // 설명 메시지
			optList = opt.optlist,
			callback = opt.callback,
			callback2 = opt.callback2,
			etcCallback = opt.etcCallback,
			cancelCallback = opt.cancelCallback,
			nextFocus = opt.nextfocus,
			selBtn = $('#'+ id),
			initVal = selBtn.closest('div').find('input[type="hidden"]').val(),
			popContainer = $('#layer_popup_container'),
			popId = 'popSelect_'+ id,
			popup = '',
			btnBottomtTxt = opt.btnBottomtTxt;
			btnBottomtDisabled = opt.btnBottomtDisabled

		// 팝업 만들기
		popup += '<div id="'+ popId +'">';
		popup += '<div class="dimmed_area on">';
		popup += '<div class="popup floating">';
		popup += '<div class="pop_header">';
		popup += '<h1>'+ title +'</h1>';
		popup += '<button type="button" class="pop_close"><span class="hidden">닫기</span></button>';
		popup += '</div>';
		popup += '<div class="pop_body">';
		popup += !!subMsg ? subMsg : '';
		popup += '<ul class="list_select">';

		$.each(optList, function(i) {
			var label = optList[i].label,
				val = optList[i].value,
				info = optList[i].info,
				activeProp = optList[i].value == initVal ? 'active' : '';

			popup += '<li>';

			if(activeProp === 'active') {
				popup += '<button type="button" class="opt_btn '+ activeProp +'" title="선택됨" value="'+ val +'">';
			}else{
				popup += '<button type="button" class="opt_btn '+ activeProp +'" value="'+ val +'">';
			}
			popup += '<span>'+ label +'</span>';

			if (!!info) {
				popup += '<span class="info">'+ info +'</span>';
			}

			popup += '</button>'
			popup += '</li>';
		});

		popup += '</ul>';
		popup += '</div>';
		popup += '<div class="pop_bottom">';
		popup += '<div class="inner">';
		popup += '<button type="button" class="pop_btn_ok"><span>'+ btnBottomtTxt +'</span></button>';
		popup += '</div>';
		popup += '</div>';
		popup += '</div>';
		popup += '<div class="dimmed"></div>';
		popup += '</div>';
		popup += '</div>';


		// 팝업 추가
		popContainer.append($(popup));

		// 버튼 화살표 회전
		selBtn.addClass('open');

		var popObj = $('#'+ popId);     // 팝업

		// popup 열기
		this.openPopup(popId);

		var optBtn = popObj.find('.opt_btn');

		// bottomBtn 셋팅
		var bottomBtn = popObj.find('.pop_btn_ok');
		if(!!btnBottomtDisabled){
			bottomBtn.addClass('disabled');
		}
		var click = false;
		var chkValue = '';
		var chkOptIdx = {};
		// option list 선택
		optBtn.off('click.selectopt').on('click.selectopt', function() {
			var optIdx = $(this).closest('li').index(),
				dispObj = selBtn.find('span'),
				hiddenInp = selBtn.closest('div').find('input[type="hidden"]');


			optBtn.removeAttr('title').removeClass('active');
			$(this).attr({'title' : '선택됨'}).addClass('active');

			dispObj.removeClass('placeholder').html(optList[optIdx].label);
			hiddenInp.val(optList[optIdx].value);

			//선택값 저장
			chkValue = optList[optIdx].value;
			// 선택값 저장(value, label 필요한 경우)
			chkOptIdx = optList[optIdx];


			// bottom버튼 활성화
			bottomBtn.removeClass('disabled');
			// 버튼 화살표 회전
//            selBtn.removeClass('open');
		});

		bottomBtn.on('click', function() {
			click = true

			// 닫은 후 focus 요소
			var returnEl = popObj.find('.popup').data('returnEl');

			if (!!returnEl.length > 0) {
				$('.inp_box').removeClass('focus');
				if (!!returnEl.attr('id')) {
					renewalUI.moveNextFocus(returnEl.attr('id'));
				} else {
					if(returnEl[0].tagName == 'H1') {
						returnEl.attr('tabindex', '0');
					}else{
						returnEl.closest('.inp_box').addClass('focus');
					}

					returnEl.focus();
				}
			}else{
				$('#Header h1').attr('tabindex', '0').focus();
			}

			// 함수 실행
			!!opt.callback &&callback(chkValue,click);
			// 함수 실행(value, label 필요한 경우)
			!!opt.callback2 && callback2(chkOptIdx,click);
			// combo-popup 닫기
			selectPopClose();
		});


		// 팝업 이외의 영억 클릭 시 etcCallback option이 있는 경우 etcCallback 함수 호출
		if (!!etcCallback) {
			$('#'+ popId).find('.dimmed').off('click.combodim').on('click.combodim', function() {
				etcCallback();
			});
		}else{
			// 팝업 이외의 영역 클릭 시
			$('#'+ popId).find('.dimmed').off('click.combodim').on('click.combodim', function() {
				// 버튼 화살표 회전
				selBtn.removeClass('open');
			});

		}

		if(!!cancelCallback){
			popObj.find('.pop_close').on('click', function() {
				// 버튼 화살표 회전
				selBtn.removeClass('open');
				cancelCallback();
			});
		}else{
			// 팝업 닫기 버튼 클릭 시
			popObj.find('.pop_close').on('click', function() {
				// 버튼 화살표 회전
				selBtn.removeClass('open');
			});
		}

		// combo-popup 닫기
		function selectPopClose() {
			// 버튼 화살표 회전
			selBtn.removeClass('open');

			// popup 닫기
			popObj.find('.popup').removeClass('open');
			renewalUI.allowScroll();

			var timer = setTimeout(function() {
				//팝업 외 다른영역 포커스 진입 방지 해제
				popObj.attr({'aria-hidden' : true});
				if(popContainer.find('.popup.open').length == 0) {
					$('.renew .skipnav, #Wrap').removeAttr('aria-hidden');
				}else{
					popContainer.find('.popup.open').closest('[aria-hidden]').attr({'aria-hidden' : false});
				}

				popObj.find('.dimmed_area').removeClass('on');
				popObj.remove();

				clearTimeout(timer);
			}, 300);

			// 다음 focus 이동
			if (nextFocus == true || nextFocus == 'undefined') {
				renewalUI.moveNextFocus();
			}
		}
	},

	listSelectFnc: function() {
		var listSelecteEl = $('[ui-list-selected]');
		if(!listSelecteEl.length) return;
		var optItems = $('[class^="btn_senior_link"]', listSelecteEl);

		var initFnc = function() {
			listSelecteEl.each(function() {
				var thisSelectEl = $(this);
				var thisOptItems = $('[class^="btn_senior_link"]', thisSelectEl);

				thisOptItems.attr({'aria-selected' : false});
				$('[class^="btn_senior_link"].active', thisSelectEl).attr({'aria-selected' : true});
			});
		}

		optItems.off('click.listSlctOpt').on('click.listSlctOpt', function() {
			var _thisOpt = $(this);
			var _thisWrap = _thisOpt.closest('[ui-list-selected]');
			var _opts = $('[class^="btn_senior_link"]', _thisWrap);
			var _clickCall = _thisOpt.data('clickCall');

			if(!_thisOpt.hasClass('active')) {
				_opts.attr({'aria-selected' : false}).removeClass('active');
				_thisOpt.attr({'aria-selected' : true}).addClass('active');
			}

			if(_clickCall) _clickCall(_thisOpt);

		});

		initFnc();
	},


	// combo-box(select box) selected - popup type
	selectedPopCombo: function(opt) {
		var id = opt.id,
			selValue = opt.selValue,
			dispText = opt.dispText,
			selBtn = $('#'+ id),
			btnTxtObj = selBtn.find('span'),
			hiddenInp = selBtn.siblings('input[type="hidden"]');

		btnTxtObj.removeClass('placeholder').html(dispText);
		hiddenInp.val(selValue);
	},

	// 각종 유형 선택하기 - bottom-up 팝업 내
	selectType: function(opt) {
		var id = opt.id,
			callback = opt.callback,
			opt = $('#'+ id).find('.opt_btn');

		// 항목 선택
		opt.off('click.seltype').on('click.seltype', function() {
			var selVal = $(this).val();

			opt.removeClass('active');
			$(this).addClass('active');

			// callback 함수 실행
			!!callback && callback(selVal);
		});
	},

	// tab content
	setTabContent: function(selector) { //selector 파라미터 추가 (20250612)
		//var tabConts = $('.tab_contents'); //삭제
		var tabConts = selector ? $(selector) : $('.tab_contents'); //추가

		if (!!tabConts.length < 1) return false;

		$.each(tabConts, function(key, cont) {
			var tabCont = $(cont),
				tabList = tabCont.find('.tab_list'),
				tabBtn = tabCont.find('.tab_btn'),
				tabPanel = tabCont.find('.tab_panel'),
				keyNo = key + 1;

			// tab list 초기 설정
			tabList.attr('role', 'tablist');

			// tab type일 경우 bar 초기 설정
			if (!!tabList.hasClass('type_tab')) {
				tabList.append('<span class="bar"></span>');

				tabBarMove();

				$(window).on('resize', function() {
					tabBarMove();
				});
			}

			// tab type일 경우 bar 위치/크기 설정
			function tabBarMove() {
				var selTab = tabList.find('.tab_btn.selected'),
					selTabL = selTab.offset().left,
					selTabW = selTab.outerWidth();

				tabList.find('.bar').css({ left: selTabL +'px', width: selTabW +'px' });
			}

			$.each(tabBtn, function(i, tab) {
				var tab = $(tab),
					idxNo = i + 1,
					tabId = 'tab'+ keyNo +'_'+ idxNo,
					panelId = 'tabPanel'+ keyNo +'_'+ idxNo,
					tabSelected = !!tab.hasClass('selected') ? true : false,
					panSelected = !!tabPanel.eq(i).hasClass('active') ? false : true;

				// tab 초기 설정
				tab.attr({ 'id': tabId, 'role': 'tab', 'aria-controls': panelId, 'aria-selected': tabSelected });

				// tab panel 초기 설정
				tabPanel.eq(i).attr({ 'id': panelId, 'role': 'tabpanel', 'aria-labelledby': tabId, 'aria-hidden': panSelected });

				// tab click
				tab.off('click.tabclick').on('click.tabclick', function() {
					tabBtn.removeClass('selected').attr({ 'aria-selected': false });
					tabPanel.removeClass('active').attr({ 'aria-hidden': true });

					$(this).addClass('selected').attr({ 'aria-selected': true });
					tabPanel.eq(i).addClass('active').attr({ 'aria-hidden': false });

					// tab type일 경우, bar 이동
					if (!!tabList.hasClass('type_tab')) {
						var tabBar = tabList.find('.bar'),
							tabL = $(this).offset().left,
							tabW = $(this).outerWidth();

						tabBar.css({ left: tabL +'px', width: tabW +'px' });
					}

					// tab 안에 accordion이 있을 경우, accordion close
					if (!!tabPanel.eq(i).find('.accordion')) {
						var accBtn = tabPanel.eq(i).find('.acc_btn'),
							accPan = tabPanel.eq(i).find('.acc_panel');

						accBtn.removeClass('open').attr({'aria-expended': false});
						accPan.css({ display: 'none' });
					}
				});
			});
		});
	},

	// 오늘 날짜 default
	setTodayPicker: function() {
		var calendarBtn = $('button.calendar');

		if (calendarBtn.length < 1) return false;

		$.each(calendarBtn, function(i, btn) {
			var dateInp = $(btn).closest('.inp_box').find('.inp_txt'),
				now = new Date(),
				nowYear = now.getFullYear(),
				nowMonth = (now.getMonth() + 1) < 10 ? '0' + (now.getMonth() + 1) : now.getMonth() + 1,
				nowDate = now.getDate() < 10 ? '0' + now.getDate() : now.getDate(),
				today = nowYear +''+ nowMonth +''+ nowDate;

			if (dateInp.attr('data-default-today') !== 'false') dateInp.val(today);
		});
	},

	// popup 열기
	openPopup: function(param) {
		var popId = typeof(param) == 'string' ? param : typeof(param) == 'object' ? param.id : '',
			okCallback, cancelCallback, etcCallback,
			popObj = $('#'+ popId),
			popup = popObj.find('.popup'),
			dimArea = popObj.find('.dimmed_area'),
			closeBtn = popObj.find('.pop_close'),       // 팝업의 닫기 버튼
			okBtn = popObj.find('.pop_btn_ok'),         // 팝업의 ok 버튼
			etcBtn = popObj.find('.pop_btn_line'),      // 팝업의 line 버튼
			cancelBtn = popObj.find('.pop_btn_gray'),   // 팝업의 cancel 버튼
			popContainer = $('#layer_popup_container');

		if (typeof(param) == 'object') {
			okCallback = param.okCallback;          // 팝업의 ok 버튼 실행 callback 함수
			cancelCallback = param.cancelCallback;  // 팝업의 cancel 버튼 실행 callback 함수
			etcCallback = param.etcCallback;        // 팝업의 line 버튼 실행 callback 함수
		}

		// 뒷화면 scroll 막기
		this.notScroll();

		// 열기 전 focus 요소 저장
		this.prevFocusSave(popup);

		dimArea.addClass('on');

		//팝업 외 다른영역 포커시 진입 방지
		popObj.attr({'aria-hidden' : false});
		if(popContainer.find('.popup.open').length > 0) {
			popContainer.find('.popup.open').closest('[aria-hidden]').attr({'aria-hidden' : true});
		}else{
			$('.renew .skipnav, .renew #Wrap').attr({'aria-hidden' : true});
		}

		popup.addClass('open');

		var timer = setTimeout(function() {
			renewalUI.setTabRadio();

			// 팝업에 포커스 이동
			popup.attr({'tabindex' : 0}).focus();

			// 전체 팝업일 때만 초기 설정 실행
			if (!!popup.hasClass('full') || !!popup.hasClass('floating')) {
				renewalUI.init(popId);
			}

			// 팝업 이외의 영역 클릭 시 팝업 닫기
			dimArea.find('.dimmed').on('click.popetc', function() {
				// renewalUI.closePopup(popId);
				if(!$(this).hasClass('noClick')) popup.find('.pop_close').trigger('click');
			});

			// 팝업의 ok 버튼 실행
			if (!!okCallback) {
				okBtn.off('click.popokbtn').on('click.popokbtn', function() {
					okCallback();
				});
			}

			// 팝업의 ok, cancel 이외의 버튼 실행
			if (!!etcCallback) {
				etcBtn.off('click.popetcbtn').on('click.popetcbtn', function() {
					etcCallback();
				});
			}

			// 팝업의 cancel 버튼 실행
			if (!!cancelCallback) {
				cancelBtn.off('click.popcancelbtn').on('click.popcancelbtn', function() {
					cancelCallback();

					// 팝업 닫기
					renewalUI.closePopup(popId);
				});
			}

			// 팝업의 닫기 버튼
			closeBtn.off('click.popclosebtn').on('click.popclosebtn', function() {
				// 팝업 닫기
				renewalUI.closePopup(popId);
			});

			clearTimeout(timer);
		}, 500);
	},

	// alert pop open
	openAlert: function(opt) {
		var id = opt.id,                // alert popup id
			sort = opt.sort,            // icon 종류
			msg = opt.message,          // 주요 메시지, html형태
			subMsg = opt.subMessage,    // 설명 메시지
			btnTxt = opt.btnText,       // 버튼 텍스트
			callback = opt.callback,    // callback
			popContainer = $('#layer_popup_container'),   // popup container
			popId = 'popAlert_'+ id,
			popup = '';

		// alert popup 만들기
		popup += '<div id="'+ popId +'">';
		popup += '<div class="dimmed_area">';
		popup += '<div class="popup alert">';
		popup += '<div class="pop_body">';
		popup += '<p class="info_txt '+ sort +'">';
		popup += msg;
		popup += '</p>';
		popup += !!subMsg ? '<span class="info_sub">'+ subMsg +'</span>' : '';
		popup += '</div>';
		popup += '<div class="pop_bottom">';
		popup += '<div class="inner">';
		popup += '<button type="button" class="pop_btn_ok"><span>'+ btnTxt +'</span></button>';
		popup += '</div>';
		popup += '</div>';
		popup += '</div>';
		popup += '<div class="dimmed"></div>';
		popup += '</div>';
		popup += '</div>';

		// alert popup 추가
		popContainer.append($(popup));

		// alert popup open
		this.openPopup(popId);

		// alert popup 버튼
		var popOkBtn = $('#'+ popId).find('.pop_btn_ok');

		// alert popup 버튼 click
		popOkBtn.off('click.popalert').on('click.popalert', function() {
			// callback 있을 경우 실행
			!!callback && callback();

			// alert popup 닫기
			renewalUI.closePopup(popId);
		});
	},

	// confirm pop open
	openConfirm: function(opt) {
		var id = opt.id,                            // alert popup id
			sort = opt.sort,                        // icon 종류
			msg = opt.message,                      // 주요 메시지, html형태
			subMsg = opt.subMessage,                // 설명 메시지, html 형태
			btnOkTxt = opt.btnOkText,               // ok 버튼 텍스트
			btnCancelTxt = opt.btnCancelText,       // cancel 버튼 텍스트
			okCallback = opt.okCallback,            // ok 버튼 callback
			cancelCallback = opt.cancelCallback,    // cancel 버튼 callback
			popContainer = $('#layer_popup_container'),   // popup container
			popId = 'popConf_'+ id,
			popCloseBtn = opt.popCloseBtn, //팝업닫기버튼추가 202310
			popup = '';

			console.log('subMsg = ', subMsg);

		// confirm popup 만들기
		popup += '<div id="'+ popId +'">';
		popup += '<div class="dimmed_area">';
		popup += '<div class="popup confirm">';
		popup += '<div class="pop_body">';
		popup += !!popCloseBtn ? '<a class="pop_close_btn" '+ popCloseBtn +'>팝업닫기</a>' : '';
		popup += '<p class="info_txt '+ sort +'">';
		popup += msg;
		popup += '</p>';
		popup += !!subMsg ? '<span class="info_sub">'+ subMsg +'</span>' : '';
		popup += '</div>';
		popup += '<div class="pop_bottom">';
		popup += '<div class="inner">';
		popup += '<button type="button" class="pop_btn_gray"><span>'+ btnCancelTxt +'</span></button>';
		popup += '<button type="button" class="pop_btn_ok"><span>'+ btnOkTxt +'</span></button>';
		popup += '</div>';
		popup += '</div>';
		popup += '</div>';
		popup += '<div class="dimmed"></div>';
		popup += '</div>';
		popup += '</div>';

		// confirm popup 추가
		popContainer.append($(popup));

		// confirm popup open
		this.openPopup(popId);

		// confirm popup 버튼
		var okBtn = $('#'+ popId).find('.pop_btn_ok'),
			cancelBtn = $('#'+ popId).find('.pop_btn_gray'),
			closeBtn = $('#'+ popId).find('.pop_close_btn');

		// confirm popup ok 버튼
		okBtn.off('click.popconfok').on('click.popconfok', function() {
			// ok callback 있을 경우
			!!okCallback && okCallback();

			// confirm popup 닫기
			renewalUI.closePopup(popId);
		});

		// confirm popup cancel 버튼
		cancelBtn.off('click.popconfcancel').on('click.popconfcancel', function() {
			// cancel callback 있을 경우
			!!cancelCallback && cancelCallback();

			// confirm popup 닫기
			renewalUI.closePopup(popId);
		});
		// confirm popup close 버튼
		closeBtn.off('click.popconfclose').on('click.popconfclose', function() {
			// confirm popup 닫기
			renewalUI.closePopup(popId);
		});
	},

	// popup 닫기
	closePopup: function(_id) {
		var popObj = $('#'+ _id),
			popup = popObj.find('.popup'),
			dimArea = popObj.find('.dimmed_area'),
			popContainer = $('#layer_popup_container');

		popup.removeClass('open').removeAttr('style'); /* 1109변경 */

		// 뒷화면 scroll 허용
		this.allowScroll();

		// 닫은 후 focus 요소
		var returnEl = popup.data('returnEl');

		var timer = setTimeout(function() {
			// select box popup일 경우
			if (_id.indexOf('popSelect') > -1 || _id.indexOf('popAlert') > -1 || _id.indexOf('popConf') > -1) {
				popObj.remove();
			} else {
				dimArea.removeClass('on');
			}

			// 닫은 후 focus 이동
			if(!!returnEl) {
				if (!!returnEl && !!returnEl.length > 0) {
					$('.inp_box').removeClass('focus');

					if (!!returnEl.attr('id')) {
						renewalUI.moveNextFocus(returnEl.attr('id'));
					} else {
						if(returnEl[0].tagName == 'H1') {
							returnEl.attr('tabindex', '0');
						}else{
							returnEl.closest('.inp_box').addClass('focus');
						}
						returnEl.focus();
					}
				}else{
					$('#Header h1').attr('tabindex', '0').focus();
				}
			}

			//팝업 외 다른영역 포커스 진입 방지 해제
			popObj.attr({'aria-hidden' : true});
			if(popContainer.find('.popup.open').length == 0) {
				$('.renew .skipnav, #Wrap').removeAttr('aria-hidden');
			}else{
				popContainer.find('.popup.open').closest('[aria-hidden]').attr({'aria-hidden' : false});
			}

			clearTimeout(timer);
		}, 500);
	},

	// popup open 시 뒷화면 scroll 막기
	notScroll: function() {
		var scrTop = $('html').scrollTop();

		$('html').css({ top: scrTop +'px', overflow: 'hidden' });
	},

	// popup close 시 뒷화면 scroll 허용
	allowScroll: function() {
		// 열려있는 팝업이 있을 경우 제외
		if ($('#layer_popup_container').find('.popup.open').length > 0) return false;

		$('html').removeAttr('style');
	},

	// gnb menu open/close
	gnbMenu: function() {
		var gnbMenu = $('#GnbWrap'),
			gnbBox = $('.gnb_wrap', gnbMenu),
			openBtn = $('#Header').find('.btn_menu'),
			closeBtn = gnbMenu.find('.btn_menu_close'),
			logoEl = $('#Header').find(' > [class^="logo"]'),
			btnRightEl = $('#Header  > [class^="btns_right"]'),
			btnLeftEl = $('#Header  > [class^="btns_left"]'),
			dimmedEl = $('.dimmed', gnbMenu),
			skipNav = $('body > .skipnav'),
			continerEl = $('#Container');

		if($('#Header > .header_wrap').length) {//개발 화면 대응
			logoEl = $('#Header > .header_wrap > [class^="logo"]'),
			btnLeftEl = $('#Header > .header_wrap > [class^="btns_left"]'),
			btnRightEl = $('#Header > .header_wrap > [class^="btns_right"]');
		}

		// 초기화\
		gnbMenu.attr({'aria-hidden' : true});
		dimmedEl.attr({'aria-hidden' : true});
		gnbBox.attr({'tabindex': '0'})

		// 열기 버튼
		openBtn.off('click.gnbopen').on('click.gnbopen', function() {
			// 열기 전 focus 요소 저장
			renewalUI.prevFocusSave(gnbMenu);

			// 전체메뉴 이외 포커스 진입 방지
			gnbMenu.find('.gnb_body').scrollTop(0);
			gnbMenu.addClass('open').attr({'aria-hidden' : false});
			gnbBox.focus();

			// 전체메뉴 이외 포커스 진입 방지
			if(btnLeftEl.length) {
				btnLeftEl.attr({'aria-hidden' : true});
			}
            skipNav.attr({'aria-hidden' : true});
			btnRightEl.attr({'aria-hidden' : true});
			logoEl.attr({'aria-hidden' : true});
			continerEl.attr({'aria-hidden' : true});

			// 뒷화면 scroll 막기
			renewalUI.notScroll();
		});

		// 닫기 버튼
		closeBtn.off('click.gnbclose').on('click.gnbclose', function() {
			gnbMenu.removeClass('open').attr({'aria-hidden' : true});

			gnbBox.removeAttr('tabindex');
			// 전체메뉴 이외 포커스 진입 방지 해제
			if(btnLeftEl.length) {
				btnLeftEl.removeAttr('aria-hidden');
			}
            skipNav.removeAttr('aria-hidden');
			btnRightEl.removeAttr('aria-hidden');
			logoEl.removeAttr('aria-hidden');
			continerEl.removeAttr('aria-hidden');

			// 열기 전 요소에 focus
			gnbMenu.data('returnEl').focus();

			// 뒷화면 scroll 허용
			renewalUI.allowScroll();
		});
	},

	// 이전 focus 요소 저장
	prevFocusSave: function(popEl) {
		var focusEl = $(':focus');

		popEl.data('returnEl', focusEl);

		console.log('focusEl ==========>', focusEl);

		// $(document).on('click', function(e) {
		// 	prevFocus = $(e.target);
		// });
	},

	// loading
	loading: function() {
		var blockUI = $('<div class="block-ui-container"><div class="block-ui-overlay"></div></div>'),
			loadObj = '';

		loadObj += '<div class="loading">';
		loadObj += '<div class="logo_meritz"><span class="hidden">로딩중입니다.</span></div>';
		loadObj += '</div>';

		blockUI.append(loadObj);
		$('body').append(blockUI).addClass('block-ui-active').addClass('block-ui-visible');
	},

	// 금액 천단위 콤마
	thousandComma: function(_val) {
		var price = _val.toString().replace(/[^0-9]/g, '').replace(/\,/g, '').replace(/(\d)(?=(?:\d{3})+(?!\d))/g, '$1,');
		return price;
	},

	// card list animation
	cardCnt: 0,
	cardListAni: function(listEl) {
		var listObj = listEl ? listEl : $('.card_wrap');

		// card list가 없거나, 팝업에 card가 있을 때 제외
		if (listObj.length < 1 || listObj.closest('.popup').length > 0) return false;

		var showContract = setInterval(function() {
			var item = listObj.find('.card_item');

			item.eq(renewalUI.cardCnt).addClass('show');

			if (renewalUI.cardCnt < item.length) {
				renewalUI.cardCnt++;
			} else {
				clearInterval(showContract);
				renewalUI.cardCnt = 0;
			}
		}, 100);
	},

	// 원하는 위치로 화면 스크롤
	toScrollScreen: function(_id) {
		var target = $('#'+_id),
			header = target.closest('.popup').length > 0
					? target.closest('.popup').find('.pop_header')
					: $('#Header');
			headerH = header.outerHeight(),
			scrBody = target.closest('.popup').length > 0
					? target.closest('.popup')
					: $('html');
			targetPos = target.offset().top - headerH - 36;

		scrBody.animate({ scrollTop: targetPos +'px' }, 400);
	},

	// disabled UI 적용
	setDisabled: function(opt) {
		var id = opt.id,
			disabled = opt.disabled,
			btn = $('#'+ id);

		if (disabled == true) {
			btn.addClass('disabled');
		} else {
			btn.removeClass('disabled');
		}
	},

	// listToggle
	listToggle: function() {
		var list = $('.board_list'),
			listItem = list.find('.board_inner'),
			toggleBtn = list.next('.list_toggle'),
			listWrp = list.parent(),
			listCount = listItem.length;

		var countTxt = $('.accountLength');

		countTxt.html('외 ' + listCount + '건');

		toggleBtn.on('click',function(){
			var listStatus = list.css('display');

			if(listStatus == 'none'){
				toggleBtn.find('span').text('닫기');
				countTxt.hide();
				$(this).addClass('open');
			}else{
				toggleBtn.find('span').text('상세 내역');
				countTxt.show();
				$(this).removeClass('open');
			}
			$('html,body').animate({scrollTop:listWrp.offset().top - 56},300);
			list.slideToggle();
		})
	},

	// 신규 추가(2차 이후)
	// voidAccordion (기능만 있음, 디자인 없음)
	voidAccordion: function() {
		const accordion = document.querySelectorAll("[data-accordion=accordion]");
		// toggle
		const toggle = function(val, idx) {
			let num = 0;
			for (const item of val) {
				if (item.classList.contains("acc-lock") === false) {
					let header = item.querySelector("[data-accordion=header]");
					let panel = item.querySelector("[data-accordion=panel]");
					let btn = header.querySelector("[data-accordion=btn]");
					panel.style.height = "0";

					// 접근성 코드
					num++;
					btn.setAttribute("aria-expanded", "false");
					btn.setAttribute("aria-controls", `ui-acc-${idx}-${num}`);
					panel.setAttribute("id", `ui-acc-${idx}-${num}`);

					// 자동 닫기 일때
					let autoClose = btn.closest(".auto_close[data-accordion=accordion]");

					// evt
					const open = function() {
						// 자동 닫기 일때
						if (autoClose) {
							let stayAcc = autoClose.querySelectorAll("[data-accordion=item]");
							stayAcc.forEach(item => {
								let stayBtn = item.querySelector("[data-accordion=btn]");
								let stayPanel = item.querySelector("[data-accordion=panel]");
								item.classList.remove("active");
								stayBtn.classList.remove("open");
								if(!stayBtn.classList.contains("open")) {
									stayPanel.style.height = "0";
									stayPanel.style.opacity = "0";
									stayPanel.setAttribute("aria-hidden", "true");
									// 접근성 코드
									stayBtn.querySelector("span").innerText = "열기";
									stayBtn.setAttribute("aria-expanded", "false");
								}
							});
						}

						// 패널 펼쳐짐
						panel.style.height = "auto";
						let ph = panel.clientHeight;
						panel.style.height = "0";
						setTimeout(() => {
							panel.style.height = `${ph}px`;
							item.classList.add("active");
							btn.classList.add("open");
							panel.style.opacity = "1";
							
							panel.setAttribute("aria-hidden", "false");
						}, 0);

						// 접근성 코드
						btn.querySelector("span").innerText = "닫기";
						btn.setAttribute("aria-expanded", "true");
					}
					const close = function() {
						btn.classList.remove("open");
						panel.style.height = "0";
						panel.style.opacity = "0";
						panel.setAttribute("aria-hidden", "true");

						// 접근성 코드
						btn.querySelector("span").innerText = "열기";
						btn.setAttribute("aria-expanded", "false");
					}

					// open class
					if (btn.classList.contains("open")) {
						item.classList.add("active");
						setTimeout(() => {
							panel.style.height = "auto";
							item.classList.add("active");
							btn.classList.add("open");
							panel.style.opacity = "1";

							// 접근성 코드
							btn.querySelector("span").innerText = "닫기";
							btn.setAttribute("aria-expanded", "true");
						}, 0);
					}

					header.addEventListener("click", function(){
						item.classList.toggle("active");
						if (item.classList.contains("active")) {
							open();
						} else {
							close();
						}
					})
				} else {
					let panel = item.querySelector("[data-accordion=panel]");
					let btn = item.querySelector("[data-accordion=btn]");
					btn.classList.add("hide");
					panel.classList.add("hide");
				}
			}
		}

		if (accordion.length >= 1) {
			let idx = 0;
			for (const item of accordion) {
				let accItem = item.querySelectorAll("[data-accordion=item]");
				idx++;
				if(accItem.length >= 1) {
					toggle(accItem, idx);
				}
			}
		}
	},

	// 디지털ARS 키패드 동작시 dArsBtns 숨김, 포커스 이동
	dArsAutoFocus: function() {
		const dArsBtns = document.querySelector(".dArs_btns:not(.ng-hide)");
		const floatingBtm = document.querySelector(".floating_btm.custom_ars");
		// runFocus 이벤트
		const runFocus = () => {
			const formItems = document.querySelectorAll(".contents .form_item .inp_txt");
			// height
			const defaultSpace = 40;
			let headerH = 0;
			let darsbarH = 0;
			let header = document.querySelector("#Header");
			let darsbar = document.querySelector(".dARS_bar");
			if (header) {
				headerH = header.clientHeight;
			}
			if (darsbar) {
				darsbarH = darsbar.clientHeight;
			}
			if (formItems.length > 0) {
				for (const item of formItems) {
					item.addEventListener("focusin", () => {
						let top = (window.scrollY + item.getBoundingClientRect().top) - defaultSpace - darsbarH - headerH;
						window.scrollTo({ left: 0, top: top, behavior: "smooth" });
						// console.log(top);
						// console.log("focusin");
						// dArsBtns 동작
						dArsBtns.classList.add("ng-hide");
						if(floatingBtm) {
							floatingBtm.classList.remove("custom_ars");
						}
					})
					item.addEventListener("focusout", () => {
						// console.log("focusout");
						// dArsBtns 동작
						dArsBtns.classList.remove("ng-hide");
						if(floatingBtm) {
							floatingBtm.classList.add("custom_ars");
						}
					})
				}
			}
		}
		// dArsevent : .dArs_btns이 있고 .ng-hide가 아닐때 동작
		if (dArsBtns) {
			runFocus();
		}
	},

	// accordion last 최소높이 설정
	setAccordionLast: function() {
		// target
		const accLast = document.querySelectorAll(".renew .accordion.last");
		const renew = document.querySelector("body.renew");
		// setMinheight
		const setMinheight = () => {
			for (const item of accLast) {
				// 바닥의 accordian last
				if (item.closest(".renew #Container") && !item.closest(".renew #layer_popup_container")) {
					const wrap = item.closest(".renew #Wrap").clientHeight;
					let container = item.closest(".renew #Container").clientHeight;
					let hv;
					hv = wrap - container
					if (hv > 0) {
						item.style.minHeight = `${item.clientHeight + hv}px`;
					} else if (hv < 0) {
						item.style.minHeight = "auto";
					}
				// 팝업의 accordian last
				} else if (item.closest(".renew #layer_popup_container .popup.full")) {
					const layer = item.closest(".renew #layer_popup_container .popup.full").clientHeight;
					const popup = item.closest(".renew #layer_popup_container .popup.full .pop_body").clientHeight;
					const hv = layer - popup
					if (hv > 0) {
						// console.log(hv);
						// console.log(item);
						// console.log(layer);
						// console.log(popup);
						item.style.minHeight = `${item.clientHeight + hv}px`;
					} else if (hv < 0) {
						item.style.minHeight = "auto";
					}
				}
			}
		}
		// observer
		let observer = new MutationObserver(() => {
			setMinheight();
		});
		let option = {
			attributes: true,
			childList: true,
			CharacterData: true,
			subtree: true,
		}
		// run
		if (accLast.length > 0) {
			observer.observe(renew, option);
			setMinheight();
		}
	},

	//20250612 switch (on/off 전환 체크박스)
	switchOnOff: function(){
		document.querySelectorAll('.switch_input').forEach(input => {
			input.addEventListener('change', (e) => {
				const targetId = e.target.dataset.target;
				const statusText = document.getElementById(targetId);
				const isChecked = e.target.checked;
				e.target.setAttribute('aria-checked', isChecked ? 'true' : 'false');
				if (statusText) statusText.textContent = isChecked ? '켜짐' : '꺼짐';
			});
		});
	}
};


var seniorUI = {
	init: function() {
		// this.seniorSwitchFn();//헤더 영역 클글씨 전환 버튼
		if($('body.senior').length) {
			this.txtAreaSet(); // 큰글씨 textarea 요서 셋팅
			this.accordionSeniorFnc(); // 큰글씨 아코디언
			this.switchItemFnc(); // 스위치 버튼
			this.pageStepperFnc(); // 상단 setp bar
			this.listSelectFnc(); // 리스트 선택
		}
	},
	txtAreaSet: function() {
		var _txtareaBox = $('.inp_txtarea');
		var _txtareaEl = $('textarea', _txtareaBox);

		if(!_txtareaBox || !_txtareaBox.length) return;

		_txtareaEl.each(function() {
			var ipTxtarea = $(this);

			!!ipTxtarea.attr('readonly') && ipTxtarea.closest('.form_item').addClass('readonly');
			!!ipTxtarea.attr('disabled') && ipTxtarea.closest('.form_item').addClass('disabled');
		});


		_txtareaEl.off('focusin.txtareaFocus').on('focusin.txtareaFocus', function() {
			var _thisTxtareaEl = $(this);

			_txtareaBox.removeClass('focus');
			_thisTxtareaEl.closest('.inp_txtarea').addClass('focus');
		});

		$(document).off('click.txtareaClick').on('click.txtareaClick', function(e) {
			var target = e.target;

			if (target.tagName != 'TEXTAREA') {
				_txtareaBox.removeClass('focus');
			}
		});
	},
	seniorSwitchFn: function() {
		if(!$('#Header .btn_senior').length) return;
		var _btnSeniorSwitch = $('#Header .btn_senior');

		_btnSeniorSwitch.off('click.srnSwitch').on('click.srnSwitch', function() {
			var _thisSnrSwitch = $(this);

			if(_thisSnrSwitch.hasClass('active')) {
				_thisSnrSwitch.removeClass('active').attr({'aria-pressed' : false});
			}else{
				_thisSnrSwitch.addClass('active').attr({'aria-pressed' : true});
			}
		});
	},
	accordionSeniorFnc: function() {
		var accorSect = $('[ui-accordion-sect]');
		if(!accorSect.length) return true;

		var accorBtn = $('[ui-accordion-btn]', accorSect);

		accorBtn.each(function() {
			var _thisBtn = $(this);
			var _isOpen = _thisBtn.attr('aria-expanded'); // 상태 = false: 닫힘, true: 열림
			var _thisSect = _thisBtn.closest('[ui-accordion-sect]');
			var _thisCont = $('[ui-accordion-cont]', _thisSect);

			_isOpen = _isOpen == 'true' ? true : false;
			var _btnTxt = _thisBtn.attr('txt-open') ? (_isOpen ? _thisBtn.attr('txt-close') : _thisBtn.attr('txt-open')) : undefined;

			if(_isOpen) {
				_thisBtn.addClass('active');
				if(_btnTxt) $('[ui-txt]', _thisBtn).html(_btnTxt);

				_thisCont.attr({'aria-hidden' : false});
			}else{
				_thisBtn.removeClass('active');
				if(_btnTxt) $('[ui-txt]', _thisBtn).html(_btnTxt);

				_thisCont.attr({'aria-hidden' : true});
			}
		});

		accorBtn.off('click').on('click', function(e) {
			var _thisBtn = $(this);
			var _isOpen = _thisBtn.attr('aria-expanded'); // 상태 = false: 닫힘, true: 열림
			var _thisSect = _thisBtn.closest('[ui-accordion-sect]');
			var _thisCont = $('[ui-accordion-cont]', _thisSect);
			var _btnTxt = _thisBtn.attr('txt-open') ? _isOpen == 'true' ? _thisBtn.attr('txt-open') : _thisBtn.attr('txt-close') : undefined;
			var _accorType = _thisSect.attr('ui-accordion-sect');
			var _popupEl = _thisSect.closest('.popup');
			var _isPop = _popupEl.length ? true : false;
			_isOpen = _isOpen == 'true' ? true : false;

			if(_isOpen) {
				_thisBtn.attr({'aria-expanded' : false}).removeClass('active');
				if(_btnTxt) $('[ui-txt]', _thisBtn).html(_btnTxt);

				_thisCont.slideUp(300, function() {
					$(this).attr({'aria-hidden' : true});
				});
			}else{
				if(_accorType && _accorType !=='') {
					var activeBtn = $('[ui-accordion-sect="' + _accorType + '"] [ui-accordion-btn].active');
					var activeSect = activeBtn.closest('[ui-accordion-sect]');
					var activeConts = $('[ui-accordion-cont]', activeSect);
					activeBtn.attr({'aria-expanded' : false}).removeClass('active');
					activeConts.slideUp(300, function() {
						$(this).attr({'aria-hidden' : true});
					});
				}

				_thisBtn.attr({'aria-expanded' : true}).addClass('active');
				if(_btnTxt) $('[ui-txt]', _thisBtn).html(_btnTxt);

				_thisCont.slideDown(300, function() {
					$(this).attr({'aria-hidden' : false});

					if(_isPop) {// 팝업 내부
						var scrollPos = (_popupEl.scrollTop() + (_thisSect.offset().top - $(window).scrollTop())) - 56;
						_popupEl.animate({scrollTop : scrollPos}, 100);
					}else{// page
						var scrollPos = _thisSect.offset().top - 56;
						$('body, html').animate({scrollTop : scrollPos}, 100);
					}
				});
			}
		});
	},
	switchItemFnc: function() {
		var switchItems = $('.switch_senior_item');
		if(!switchItems.length) return;

		var switchOpt = $('.switch_opt', switchItems);

		var initFnc = function() {
			switchItems.each(function() {
				var _switchItem = $(this);
				var _switchOpt = $('.switch_opt', _switchItem);
				var _tabConts = _switchItem.closest('[class^="tab_cont"]');
				// setSwitchFn(_switchOpt);

				var switchResize = new ResizeObserver(function(entries) {
					for(var k=0; k < entries.length; k++) {
						setSwitchFn(_switchOpt);
					}
				});

				switchResize.observe(_switchItem[0]);
				if(_tabConts.length > 0) {
					var config = {
						attributes : true,
						childList : true,
						subtree : true
					};

					var observerCall = function(mutatList, observer) {
						for(var mutation of mutatList) {
							if(mutation.target.classList.value.indexOf('tab_panel') > -1) {
								setSwitchFn(_switchOpt);
							}
						}
					}

					var switchObserve = new MutationObserver(observerCall);

					switchObserve.disconnect(_tabConts[0]);
					switchObserve.observe(_tabConts[0], config);

				}
			});
		}

		var setSwitchFn = function(el) {
			el.each(function() {
				var thisBtn = $(this);
				var thisSwitchWrap = thisBtn.closest('.switch_senior_item');
				var thisBg = $('.bg', thisSwitchWrap);

				if(thisBtn.hasClass('selected')) {
					thisBtn.attr({'aria-selected' : true});
					thisBtn.attr('title', '선택됨');
					thisBg.css({
						left: thisBtn.position().left,
						width: thisBtn.outerWidth(),
					});
				}else{
					thisBtn.attr({'aria-selected' : false});
					thisBtn.attr('title', '선택안됨');
				}
			});
		}

		switchOpt.on('click', function() {
			var thisBtn = $(this);
			var thisSwitchWrap = thisBtn.closest('.switch_senior_item');
			var thisSwitchOpt = $('.switch_opt', thisSwitchWrap);
			var thisBg = $('.bg', thisSwitchWrap);

			if(!thisBtn.hasClass('selected')) {
				thisSwitchOpt.attr({'aria-selected' : false}).removeClass('selected');
				thisSwitchOpt.attr('title', '선택안됨');
				thisBtn.attr({'aria-selected' : true}).addClass('selected');
				thisBtn.attr('title', '선택됨');
				thisBg.css({
					left: thisBtn.position().left,
					width: thisBtn.outerWidth(),
				});
			}
		});

		initFnc();
	},
	pinPadUtilPos: function(options) {
		var opt = options || {};
		var targetEl = $(opt.el);

		if(opt.posB) {
			targetEl.css({
				'display': 'block',
				'bottom' : opt.posB
			});
		}
	},
	cardListAni: function(el) {// card list animation
		console.log('cardListAni === ', el);
		var cardWrap = $(el);
		var items = $('[class^="card_item"]:not(.show), [class^="item_val"]:not(.show)', cardWrap);

		items.each(function(idx, item) {
			setTimeout(function() {
				$(item).addClass('show');
			}, (idx + 1) * 100);
		});
	},
	pageStepperFnc: function() {
		var _pageStepperWrap = $('.senior_stepper_box');
		if(!_pageStepperWrap.length) return true;

		_pageStepperWrap.each(function() {
			var _thisPageStepper = $(this);
			var _stepper = $('> .stepper', _thisPageStepper);
			var _inner = $('> .inner', _stepper);
			var _stepItems = $('.step_items', _inner);
			var _stepperBar = $('> .steppr_bar', _stepper);
			var _bar = $('> span', _stepperBar);

			// step Info
			var end = parseInt(_thisPageStepper.attr('stepper-end'), 10);
			var now = parseInt(_thisPageStepper.attr('stepper-now'), 10);
			var firstW;
			var lastW;
			var _movUnitW;

			var creatHtml = function() {
				for(var createIdx = 1; createIdx <= end; createIdx++) {
					var htmlStep = '<div class="step_items" aria-hidden="true">' + createIdx + '</div>';

					if(now == createIdx) {
						htmlStep = '<div class="step_items active">' + now + '<span class="hidden">단계 / '+ end +'단계</span></div>';
					}

					_inner.append(htmlStep);
				}

				_stepItems = $('.step_items', _inner);
			}

			creatHtml();

			var stepMovCalc = function(i, el) {
				firstW = _stepItems.eq(0).outerWidth();
				lastW = _stepItems.eq(end - 1).outerWidth();
				_movUnitW = (_stepperBar.outerWidth() - firstW - lastW) / (end - 2);

				var idx = i;
				var stepEl = $(el);
				var calcDist = (_movUnitW * idx) - (_movUnitW / 2) + firstW;

				if(i == end-1) {
					_bar.css({'width' : '100%'});
				}else{

					if(i == 1) {
						if(calcDist < 25 + (stepEl.outerWidth() / 2)) calcDist = 25 + (stepEl.outerWidth() / 2);
					} else if(i == end - 2) {
						var limitDist = _stepperBar.outerWidth() - lastW - (stepEl.outerWidth() / 2) - 5;
						if(limitDist < calcDist) {
							calcDist = limitDist;
						}
					}
					stepEl.css({'left' : calcDist});
					_bar.css({'width' : calcDist+2});
				}
			}

			for(var i=0; i < end; i++) {
				var _stepItem = _stepItems.eq(i);

				if(_stepItem.hasClass('active')) {
					if(i > 0) {
						stepMovCalc(i, _stepItem);
					}
				}else{
					_stepItem.attr({'aria-hidden': true})
				}

			}

			var resizeObserver = new ResizeObserver(function(entries) {
				for(var k=0; k < entries.length; k++) {
					var activeStepItem = $('.step_items.active', _inner);
					stepMovCalc(activeStepItem.index(), activeStepItem);
				}
			});

			resizeObserver.observe(_stepper[0]);
		});
	},
	listSelectFnc: function() {
		var listSelecteEl = $('[ui-list-selected]');
		if(!listSelecteEl.length) return;
		var optItems = $('[class^="btn_senior_link"]', listSelecteEl);

		var initFnc = function() {
			listSelecteEl.each(function() {
				var thisSelectEl = $(this);
				var thisOptItems = $('[class^="btn_senior_link"]', thisSelectEl);

				thisOptItems.attr({'aria-selected' : false});
				$('[class^="btn_senior_link"].active', thisSelectEl).attr({'aria-selected' : true});
			});
		}

		optItems.off('click.listSlctOpt').on('click.listSlctOpt', function() {
			var _thisOpt = $(this);
			var _thisWrap = _thisOpt.closest('[ui-list-selected]');
			var _opts = $('[class^="btn_senior_link"]', _thisWrap);
			var _clickCall = _thisOpt.data('clickCall');
			
			if(!_thisOpt.hasClass('active')) {
				_opts.attr({'aria-selected' : false}).removeClass('active');
				_thisOpt.attr({'aria-selected' : true}).addClass('active');
			}

			if(_clickCall) _clickCall(_thisOpt);

		});

		initFnc();
	},
	listSelectFnc2: function() {
		var listSelecteEl = $('[ui-list-selected]');
		if(!listSelecteEl.length) return;

		var optItems = $('[class^="btn_senior_link02"]', listSelecteEl);

		var updateAria = function(wrapEl) {
			var thisOptItems = $('[class^="btn_senior_link02"]', wrapEl);

			thisOptItems.each(function() {
				var _item = $(this);
				// active 클래스 유무에 따라 aria-selected와 title 속성 설정
				if (_item.hasClass('active')) {
					_item.attr({'aria-selected' : true, 'title' : '선택됨'});
				} else {
					_item.attr({'aria-selected' : false, 'title' : _item.data('original-title') || _item.attr('title')});
				}
			});
		};

		var initFnc = function() {
			listSelecteEl.each(function() {
				var thisSelectEl = $(this);
				$('[class^="btn_senior_link02"]', thisSelectEl).each(function() {
					var _item = $(this);
					if (!_item.data('original-title')) {
						_item.data('original-title', _item.attr('title'));
					}
				});

				updateAria(thisSelectEl);
			});
		}

		optItems.off('click.listSlctOpt').on('click.listSlctOpt', function() {
			var _thisOpt = $(this);
			var _thisWrap = _thisOpt.closest('[ui-list-selected]');
			var _opts = $('[class^="btn_senior_link02"]', _thisWrap);
			var _clickCall = _thisOpt.data('clickCall');

			if(_thisOpt.hasClass('active')) {
				return; 
			}
			
			_opts.removeClass('active');

			_thisOpt.addClass('active');

			updateAria(_thisWrap);

			if(_clickCall) _clickCall(_thisOpt);

		});

		initFnc();
	},
	floatingBanner: function() {
		var bannerEl = $('.floating_banner');
		var bannerH = bannerEl.outerHeight();
		var contsEl = bannerEl.closest('.contents');

		contsEl.css({
			'padding-bottom' : bannerH + 40
		});
	}
}

/* 보험금청구 단계 표시 */
$(function () {
	$('.step[data-step]').each(function () {
		var $this = $(this), step = $this.data('step'), total = 12;
		$this.text(('0' + step).slice(-2) + '/' + total).attr('aria-label', '전체 ' + total + '단계 중 ' + step + '단계');
	});
});
